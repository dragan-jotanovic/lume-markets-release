# Lume Markets Platform

This pack is a Nomad job that deploys all components of lume markets platform


## Variables

Refer to each of the subprojects for detailed variables description
